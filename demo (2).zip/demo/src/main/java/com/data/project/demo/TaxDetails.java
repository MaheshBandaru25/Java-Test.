package com.data.project.demo;
	
public class TaxDetails {
    private String employeeCode;
    private String firstName;
    private String lastName;
    private double yearlySalary;
    private double taxAmount;
    private double cessAmount;

    // Constructors, getters, and setters
}

