package com.data.project.demo;

import org.springframework.stereotype.Service;
import java.time.LocalDate;

@Service
public class EmployeeService {

    private static final double TAX_RATE_1 = 0.05; // 5%
    private static final double TAX_RATE_2 = 0.1; // 10%
    private static final double TAX_RATE_3 = 0.2; // 20%
    private static final double CESS_RATE = 0.02; // 2%

    // Method to calculate tax deductions for the current financial year
    public TaxDetails calculateTaxDeduction(Employee employee) {
        // Get the Date of Joining (DOJ)
        LocalDate doj = LocalDate.parse(employee.getDoj()); // Assuming DOJ is in ISO format (yyyy-MM-dd)
        LocalDate currentDate = LocalDate.now();

        // Calculate the number of months in the current financial year (April to March)
        int financialYearMonths = calculateFinancialYearMonths(currentDate);

        // Calculate the salary for the current financial year
        double yearlySalary = employee.getSalary() / 12 * financialYearMonths;

        // Calculate tax based on the yearly salary
        double taxAmount = calculateTaxAmount(yearlySalary);

        // Apply cess if applicable
        double cessAmount = yearlySalary > 2500000 ? yearlySalary * CESS_RATE : 0;

        // Create TaxDetails object to hold tax details
        TaxDetails taxDetails = new TaxDetails();
        taxDetails.setEmployeeCode(employee.getEmployeeId());
        taxDetails.setFirstName(employee.getFirstName());
        taxDetails.setLastName(employee.getLastName());
        taxDetails.setYearlySalary(yearlySalary);
        taxDetails.setTaxAmount(taxAmount);
        taxDetails.setCessAmount(cessAmount);

        return taxDetails;
    }

    // Calculate the number of months in the current financial year (April to March)
    private int calculateFinancialYearMonths(LocalDate currentDate) {
        int year = currentDate.getMonthValue() >= 4 ? currentDate.getYear() : currentDate.getYear() - 1;
        LocalDate startFinancialYear = LocalDate.of(year, 4, 1);
        LocalDate endFinancialYear = LocalDate.of(year + 1, 3, 31);
        return (int) startFinancialYear.until(endFinancialYear).toTotalMonths();
    }

    // Calculate tax based on the yearly salary
    private double calculateTaxAmount(double yearlySalary) {
        double taxAmount = 0;
        if (yearlySalary > 1000000) {
            taxAmount = 12500 + 50000 + 100000 + (yearlySalary - 1000000) * TAX_RATE_3;
        } else if (yearlySalary > 500000) {
            taxAmount = 12500 + 100000 + (yearlySalary - 500000) * TAX_RATE_2;
        } else if (yearlySalary > 250000) {
            taxAmount = 12500 + (yearlySalary - 250000) * TAX_RATE_1;
        }
        return taxAmount;
    }
}
