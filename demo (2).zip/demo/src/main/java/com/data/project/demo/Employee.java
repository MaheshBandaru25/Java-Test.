package com.data.project.demo;


public class Employee {
    private String employeeId;
    private String firstName;
    private String lastName;
    private String email;
    private List<String> phoneNumbers;
    private LocalDate doj;
    private double salary;

    // Constructors, getters, and setters
}
